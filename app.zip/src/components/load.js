$(window).on("load",function(){
          $(".loader-wrapper").fadeOut("slow");

        }); 
// document.getElementById("mybtn").click();
