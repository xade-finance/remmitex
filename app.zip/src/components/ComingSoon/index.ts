import Cs from './soon'

export default Cs