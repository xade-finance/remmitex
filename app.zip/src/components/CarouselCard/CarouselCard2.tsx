import React from 'react'
import './CarouselCard.css'
type Props = {}

const CarouselCard2 = (props: Props) => {
  return (

         <div className="box">   
<br />
<br />
<a className="labelText">
<br />Trade 5000+ markets including global stocks, crypto, and commodities with 10x leverage</a>
<br />
<br />
<img className="carouselImg" src="https://www.xade.finance/media/coins.png" />
<br />
<br />

  </div>

  )
}

export default CarouselCard2
